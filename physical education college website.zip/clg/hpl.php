
<section>
	<div class="container section-gap"><br><br>
    <h1 class="text-center">Human Performance Laboratory</h1>
    <br>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Tools</th>
          <th>No.of</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>Stop Watches(Electronic measuring time up to 1/100th of a second)</td>
         <td>1</td>
       </tr>
       <tr>
        <td>2</td>
        <td>B.P.Apparatuses(Sphygmomanometers & Stethoscope)</td>
        <td>1</td>
      </tr>
      <tr>
       <td>3</td>
       <td>Wall Thermometer & Barometer</td>
       <td>2</td>
     </tr>
   </tbody>
   

 </table>                                                           

</div>

</section>




<section>
	<div class="container section gap"><br><br>
    <h1 class="text-center">Anatomy Physiology & Health Education Laboratory</h1>
    <br>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Tools</th>
          <th>No.of</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>Heamoglobinemeter Ahab's</td>
         <td>1</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Weighing machine personal</td>
        <td>1</td>
      </tr>
      <tr>
       <td>3</td>
       <td>Human body system chart</td>
       <td>1</td>
     </tr>
     <tr>
       <td>4</td>
       <td>Digestive system chart</td>
       <td>1</td>
     </tr>
     <tr>
      <td>5</td>
      <td>Re-Productive system chart</td>
      <td>1</td>
    </tr>
    <tr>
     <td>6</td>
     <td>Food Nutrient chart</td>
     <td>1</td>
   </tr>
   <tr>
     <td>7</td>
     <td>Communicable and Non-Communicable Diseases chart</td>
     <td>1</td>
   </tr>
   <tr>
    <td>8</td>
    <td>Road safety Devices chart</td>
    <td>1</td>
  </tr>
  <tr>
   <td>9</td>
   <td>First aid box</td>
   <td>1</td>
 </tr>
</tbody>

<br><br><br>
</table>                                                           

</div>

</section>


