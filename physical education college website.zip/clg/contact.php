<section>
	<br><br><br><br>
	<div class="container section-gap ">
		<div class="col-xs-12 col-md-12 col-lg-12 col-sm-12">
			<div class="map ">
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15254.300152241358!2d82.0682574!3d17.093427200000004!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a378165aaaaaaab%3A0x481e8b12b4b80715!2sAditya+Engineering+College!5e0!3m2!1sen!2sin!4v1527165211860frameborder="0" style="border:1px;width:100%;height:500px;"></iframe>
				
			</div>
			
		</div>
	</div>
</section>


