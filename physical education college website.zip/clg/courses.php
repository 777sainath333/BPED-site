
<?php
include("config.php");
?>
<section>
	<div class="container section-gap"><br><br>
		<h1 class="text-center">Courses</h1>
		
		<table class="table">
			<thead>
				<tr>
					<th>No</th>
					<th>Course Name</th>
					<th>Year Of Establishing</th>
					<th>Intake</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>1</td>
					<td>B.P.Ed</td>
					<td>2013-14</td>
					<td>100</td>
				</tr>
				<tr>
					<td>2</td>
					<td>D.P.Ed</td>
					<td>2016-17</td>
					<td>50</td>
				</tr>
			</tbody>
			

		</table>                                                           

	</div>

	<div class="container">
		<div class="">
			<p ><h1 class="text-center"> Seats Allocation</h1></p><br>
			<h4 class="text-center"><a class="text-center" <a href="data/petslist.pdf">Download List of Applications (PETs) In Service B.P.Ed Training 2014-15 </a><br>
				<a href="data/PROCEDDINGS.pdf"> download Proceedings</a><br><br><br><br></h4>
			</div>
			
		</div>


	</section>


