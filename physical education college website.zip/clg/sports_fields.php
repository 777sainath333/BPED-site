

<section>
	<div class="container section-gap"><br><br>
    <h1 class="text-center">Sports fields</h1>
    <br>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Fields</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>400 mtrs standard track</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Shot put.discus,Javelin,Hammer sectors</td>
      </tr>
      <tr>
       <td>3</td>
       <td> Long jump,Triple jump, Hieght jump, Pole vault.</td>
     </tr>
   </tbody>
   

 </table>                                                           

</div>

</section>
