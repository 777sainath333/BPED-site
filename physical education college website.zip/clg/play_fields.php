
<section class="section-gap">
	<div class="container section gap "><br><br>
    <h1 class="text-center">Play fields</h1> <br><br>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Fields</th>
          <th>No of fields</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>Volley ball courts</td>
         <td>2</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Throwball court</td>
        <td>1</td>
      </tr>
      <tr>
       <td>3</td>
       <td>Basket ball court</td>
       <td>1</td>
     </tr>
     <tr>
       <td>4</td>
       <td>kabaddi court</td>
       <td>1</td>
     </tr>
     <tr>
       <td>5</td>
       <td>Long Jump & Tripple Jump pit</td>
       <td>1</td>
     </tr>
     <tr>
       <td>6</td>
       <td>High jump pit</td>
       <td>1</td>
     </tr>
     <tr>
       <td>7</td>
       <td>200 mts. Track events (100,200,400 & Relay's)</td>
       <td>1</td>
     </tr>
     <tr>
       <td>8</td>
       <td>Foot ball and hockey</td>
       <td>2</td>
     </tr>
     <tr>
       <td>9</td>
       <td>cricket field</td>
       <td>1</td>
     </tr>
     <tr>
       <td>10</td>
       <td>Cricket bowling and batting nets</td>
       <td>3</td>
     </tr>
     <tr>
       <td>11</td>
       <td>Kabaddi courts</td>
       <td>2</td>
     </tr>
     <tr>
       <td>12</td>
       <td>Kho Kho courts</td>
       <td>2</td>
     </tr>
     <tr>
       <td>13</td>
       <td>Ball badminton courts</td>
       <td>2</td>
     </tr>
     <tr>
       <td>14</td>
       <td>Tenny Koit Courts</td>
       <td>2</td>
     </tr>
     <tr>
       <td>15</td>
       <td>Hand ball court</td>
       <td>1</td>
     </tr>
     <tr>
       <td>16</td>
       <td>shot put circle</td>
       <td>1</td>
     </tr>
     <tr>
       <td>17</td>
       <td>Discuss circle</td>
       <td>1</td>
     </tr>
     <tr>
       <td>18</td>
       <td>Javellin throw</td>
       <td>1</td>
     </tr>
     <tr>
       <td>19</td>
       <td> Gymnasium</td>
       <td>1</td>
     </tr>
     <tr>
       <td>20</td>
       <td>Shuttle Badminton courts Indoor</td>
       <td>2</td>
     </tr>
     <tr>
       <td>21</td>
       <td>Table Tennis boards (Gym)</td>
       <td>2</td>
     </tr>
     <tr>
       <td>22</td>
       <td>Billiards boards</td>
       <td>1</td>
     </tr>
   </tbody>
   

 </table>      
</div>
</section>

<br><br><br>
</div>
</section>
