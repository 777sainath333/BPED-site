
<section>
	<div class="container section-gap"><br><br>
    <h1 class="text-center">Library</h1>
    <br>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Books</th>
          <th>No of books</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>Total no of titles</td>
         <td>600</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Total no of books</td>
        <td>2010</td>
      </tr>
      <tr>
       <td>3</td>
       <td>Total no of Journals</td>
       <td>30</td>
     </tr>
   </tbody>
   

 </table>                                                           

</div>

</section>
