<section class="section-gap">
	<div class="container "><br><br>
    <h1 class="text-center">ICT Educational and Laboratory</h1>
    <table class="table" align="center"">
      <thead>
        <tr>
          <th>No</th>
          <th>Technology</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>Digital Camera(Canon -135)</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Plasma tv</td>
      </tr>
      <tr>
       <td>3</td>
       <td>DVD Recorder & Player</td>
     </tr>
     <tr>
       <td>4</td>
       <td>Slide projector</td>
     </tr>
     <tr>
      <td>5</td>
      <td>Photo Copier Machine</td>
    </tr>
    <tr>
     <td>6</td>
     <td>Media projector</td>
     
   </tr>
   <tr>
     <td>7</td>
     <td>Video Camera (Handy Cam Digital Sony DCR SR68E )</td>
   </tr>
   <tr>
    <td>8</td>
    <td>Desk Tops (TFT)</td>
  </tr>
  <tr>
   <td>9</td>
   <td>Colour printer</td>
 </tr>
 <tr>
   <td>10</td>
   <td>Public Address System</td>
 </tr>
 <tr>
  <td>11</td>
  <td>Display Boards (3x2)</td>
</tr>
<tr>
 <td>12</td>
 <td>Computer Laboratory with fifteen desktops (TFT) & internet</td>
</tr>
<tr>
 <td>13</td>
 <td>Lap Tops for Teaching Faculty Member.</td>
</tr>
</tbody>

<br>
</table>                                                           
<br><br><br>
</div>

</section>