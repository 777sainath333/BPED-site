
<section class="section-gap">
	<div class="container "><br><br>
    <h1 class="text-center">Sports Psychology Laboratory</h1>
    <table class="table" align="center">
      <thead>
        <tr>
          <th>No</th>
          <th>Tools</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>KOH'S BLOCK DESIGN TEST</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Pass Along Test</td>
      </tr>
      <tr>
       <td>3</td>
       <td>PATTREN DRAWING TEST</td>
     </tr>
     <tr>
       <td>4</td>
       <td>IMMEDEATE MEMORY TEST
       </td>
     </tr>
     <tr>
      <td>5</td>
      <td>PICTURE CONSTRUCTION TEST</td>
    </tr>
    <tr>
     <td>6</td>
     <td>STEP MAZE TEST</td>
     
   </tr>
   <tr>
     <td>7</td>
     <td>MANTAL HEALTH CHECK LIST</td>
   </tr>
   <tr>
    <td>8</td>
    <td>KUDAR INTROVERSION, EXTROVERSION TEST</td>
  </tr>
  <tr>
   <td>9</td>
   <td>BELLS ADJUSTMENT INVENTORY TEST</td>
 </tr>


 <tr>
   <td>10</td>
   <td>ZIGARNIC EFFECT TEST</td>
 </tr>
 <tr>
  <td>11</td>
  <td>EMOTIONAL INTELLIGENCE TEST</td>
</tr>
<tr>
 <td>12</td>
 <td>CREATIVITY TEST</td>
</tr>
<tr>
 <td>13</td>
 <td>SELF CONCEPT TEST</td>
</tr>
<tr>
  <td>14</td>
  <td>MULLER-LYER ILLUSION FIGURE(WITH STAND AND SCALE)</td>
</tr>
<tr>
 <td>15</td>
 <td>LIFTED WEIGHTS SET</td>
 
</tr>
<tr>
 <td>16</td>
 <td>PHI-PHENOMENON APPARATUS</td>
</tr>
<tr>
  <td>17</td>
  <td>WHIPPLES WEIGHT BOX</td>
</tr>
<tr>
 <td>18</td>
 <td>SHAPE AND SIZE DISCRIMINATION</td>
</tr>


<tr>
 <td>19</td>
 <td>CONFLICT BOARD</td>
</tr>
<tr>
  <td>20</td>
  <td>ELECTRIC MAZE</td>
</tr>
<tr>
 <td>21</td>
 <td>PUNCH BOARD MAZE</td>
</tr>
<tr>
 <td>22</td>
 <td>MIRROR DRAWING APPARTUS</td>
</tr>
<tr>
  <td>23</td>
  <td>HAND WITH DRAWAL APPARATUS</td>
</tr>
<tr>
 <td>24</td>
 <td>TACHISTO SCOPE</td>
 
</tr>
<tr>
 <td>25</td>
 <td>R.T. APPARATUS</td>
</tr>
<tr>
  <td>26</td>
  <td>FINGER DYNAMOMETER</td>
</tr> 
<tr>
 <td>27</td>
 <td>KOH'S BLOCK DESIGN TEST</td>
</tr>
<tr>
 <td>28</td>
 <td>T.A.T. BY UMA CHOUDHARY</td>
</tr>
<tr>
 <td>29</td>
 <td>O' CONOR'S FINGER DEXTERITY</td>
</tr>
<tr>
 <td>30</td>
 <td>STEADINESS TESTER</td>
</tr>

</tbody>

<br>
</table>                                                           
<br><br><br>
</div>

</section>
