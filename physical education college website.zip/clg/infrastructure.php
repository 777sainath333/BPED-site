
<br>
<br>
<br><br><br><br><br><br><br>+
<section>




  <div class="container"><br>
    <h1 class="text-center">Infrastrucure</h1>
    <br>
    <table class="table">
      <thead>
        <tr>
          <th>No</th>
          <th>Room</th>
          <th>No of rooms alloted</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td>1</td>
         <td>class rooms</td>
         <td>12</td>
       </tr>
       <tr>
        <td>2</td>
        <td>Multipurpose room</td>
        <td>1</td>
      </tr>
      <tr>
       <td>3</td>
       <td>seminar room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>4</td>
       <td>Library room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>5</td>
       <td>principal room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>6</td>
       <td>Administrative office room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>7</td>
       <td>store room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>8</td>
       <td>sports store room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>9</td>
       <td>Girls common room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>10</td>
       <td>Boys common room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>11</td>
       <td>Music room</td>
       <td>1</td>
     </tr>
     <tr>
       <td>12</td>
       <td>science labs</td>
       <td>2</td>
     </tr>
     <tr>
       <td>13</td>
       <td>psychology lab</td>
       <td>1</td>
     </tr>
     <tr>
       <td>14</td>
       <td>Educational Techonology(ET)ICT Lab</td>
       <td>1</td>
     </tr>
     <tr>
       <td>15</td>
       <td>other rooms</td>
       <td>3</td>
     </tr>
     <tr>
       <td>16</td>
       <td>Toilets male</td>
       <td>1</td>
     </tr>
   </tbody>
   

 </table>                                                           

</div>




</section>




<!-- End banner Area -->	

